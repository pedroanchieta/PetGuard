 package br.com.criandoapi.petguard.controller;
 
 import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.criandoapi.petguard.DAO.IAnimais;
import br.com.criandoapi.petguard.model.Animais;

@RestController
@CrossOrigin("*")
@RequestMapping("/animais")
public class AnimalController {
	
	@Autowired
	private IAnimais dao;
	
	@GetMapping
	public List<Animais> listaAnimais () {
		return (List<Animais>) dao.findAll();
	}
	
	@GetMapping("animais/{id}")
	public ResponseEntity<Animais> getAnimalById(@PathVariable String id) {
	    Optional<Animais> animalOpt = dao.findById(id);
		return null;
	}

	@PostMapping
	public Animais addAnimais (@RequestBody Animais animais) {
		Animais animalNovo = dao.save(animais);
		return animalNovo;
	}
	
	@PutMapping("animais/{id}")
	public Animais editarAnimais (@RequestBody Animais animais) {
		Animais animalNovo = dao.save(animais);
		return animalNovo;
	}
	
	@PatchMapping("animais/{id}")
	public Animais alterarStatus(@PathVariable String id, @RequestBody String status) {
		Optional<Animais> animalOpt = dao.findById(id);
		if (animalOpt.isPresent()) {
			Animais animal = animalOpt.get();
			animal.setStatus(status.trim());
			dao.save(animal);
			return animal;
		} else {
	        throw new RuntimeException("Animal não encontrado com o ID: " + id);
		}
	}
	
	@DeleteMapping("/{id}")
	public Optional<Animais> excluirAnimal (@PathVariable String id) {
		Optional<Animais> animal = dao.findById(id);
		dao.deleteById(id);
		return animal;
	}	
}
