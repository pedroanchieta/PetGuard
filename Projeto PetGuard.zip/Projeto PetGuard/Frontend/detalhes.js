document.addEventListener('DOMContentLoaded', function () {
    const urlParams = new URLSearchParams(window.location.search);
    const animalId = urlParams.get('id');

    const animalIdElement = document.getElementById('animalId');
    const especieInput = document.getElementById('especie');
    const racaInput = document.getElementById('raca');
    const idadeInput = document.getElementById('idade');
    const editForm = document.getElementById('editForm');

    if (animalId) {
        animalIdElement.textContent = animalId;
        fetch(`http://localhost:8080/animais/${animalId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erro ao carregar os detalhes do animal');
                }
                return response.json();
            })
            .then(animal => {
                especieInput.value = animal.especie;
                racaInput.value = animal.raca;
                idadeInput.value = animal.idade;
            })
            .catch(error => {
                console.error('Erro ao carregar os detalhes:', error);
            });
    } else {
        console.error('ID do animal não encontrado na URL');
    }

    editForm.addEventListener('submit', function (event) {
        event.preventDefault();  // Previne o envio do formulário
        alert('Alterações Salvas');  // Exibe a mensagem
        window.location.href = 'index.html';  // Redireciona para a página index.html
    });
});
