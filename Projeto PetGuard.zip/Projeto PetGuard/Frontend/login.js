document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.querySelector('#username').value;
    const password = document.querySelector('#password').value;

    if (username === 'admin' && password === 'senha123') {
        window.location.href = 'index.html';
    } else {
        alert('Usuário ou senha incorretos');
    }
});