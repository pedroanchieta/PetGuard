package br.com.criandoapi.petguard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetguardApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetguardApplication.class, args);
	}

}
