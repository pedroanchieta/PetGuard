package br.com.criandoapi.petguard.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "animais")
public class Animais {
	
	@Id
	@Column(name = "id", length = 50, nullable = true)
	private String id;
	
	@Column(name = "especie", length = 50, nullable = false)
	private String especie;
	
	@Column(name = "raca", length = 50, nullable = false)
	private String raca;
	
	@Column(name = "idade", columnDefinition= "INT", nullable = true)
	private int idade;
	
	@Column(name = "status", columnDefinition = "ENUM", nullable = false)
	private String status;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	public String getRaca() {
		return raca;
	}
	public void setRaca(String raca) {
		this.raca = raca;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
