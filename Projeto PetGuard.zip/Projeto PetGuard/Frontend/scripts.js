const animalForm = document.getElementById('animalForm');
const animalList = document.getElementById('animalList');

document.addEventListener('DOMContentLoaded', function () {
    loadAnimalsFromDatabase();
});

function loadAnimalsFromDatabase() {
    fetch("http://localhost:8080/animais", {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
        }
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao carregar animais do banco de dados');
            }
            return response.json();
        })
        .then(animals => {
            animals.forEach(animal => {
                addAnimalToList(animal.id, animal.especie, animal.raca, animal.idade, animal.status);
            });
        })
        .catch(error => {
            console.error('Erro ao carregar animais:', error);
        });
}

function cadastrar (id, especie, raca, idade, status) {
    fetch("http://localhost:8080/animais",
        {

            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            method: "POST",
            body: JSON.stringify({
                id: id,
                especie: especie,
                raca: raca,
                idade: idade,
                status: status
            })
        })
        .then(function (res) { console.log(res) })
        .catch(function (res) { console.log(res) })
}


animalForm.addEventListener('submit', function(event) {
    event.preventDefault();
    
    function gerarId() {
        return 'animal_' + Math.floor(100000 + Math.random() * 900000);
    }
    const id = gerarId();
    const especie = document.querySelector('.especie').value;
    const raca = document.querySelector('.raca').value;
    const idade = document.querySelector('.idade').value;
    const status = document.querySelector('.status').value;

    addAnimalToList(id, especie, raca, idade, status);
    cadastrar(id, especie, raca, idade, status);
    animalForm.reset();

});

function addAnimalToList(id, especie, raca, idade, status) {
    const row = document.createElement('tr');
    row.setAttribute('data-id', id);

    row.innerHTML = `
        <td><a style="cursor: pointer;" onclick="openDetailsPage('${id}')">${id}</a></td>
        <td>${especie}</td>
        <td>${raca}</td>
        <td>${idade}</td>
        <td>${status}</td>
        <td>
            <button onclick="alterarStatus('${id}')">Alterar Status</button>
            <button onclick="deleteAnimal('${id}', this)">Excluir</button>
        </td>
    `;

    animalList.appendChild(row);
}

function openDetailsPage(id) {
    window.location.href = `detalhes.html?id=${id}`;
}

function alterarStatus(id) {
    fetch(`http://localhost:8080/animais/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao obter o status atual do servidor');
            }
            return response.json();
        })
        .then(animal => {
            const statusOptions = ["Disponível", "Em tratamento", "Adotado"];
            const currentStatusIndex = statusOptions.indexOf(animal.status);
            
            const nextStatusIndex = (currentStatusIndex + 1) % statusOptions.length;
            const newStatus = statusOptions[nextStatusIndex];

            return fetch(`http://localhost:8080/animais/${id}`, {
                method: 'PATCH',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ status: newStatus })
            });
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao atualizar o status no servidor');
            }
            console.log('Status atualizado com sucesso no servidor');

            const statusElement = document.querySelector(`tr[data-id="${id}"] .status`);
            if (statusElement) {
                statusElement.textContent = newStatus;
            }
        })
        .catch(error => {
            console.error('Erro ao alterar o status:', error);
        });
}


function deleteAnimal(id) {
    const row = document.querySelector(`tr[data-id="${id}"]`);

    row.remove();

    fetch(`http://localhost:8080/animais/${id}`, {
        method: 'DELETE',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Erro ao excluir o animal no servidor');
        }
        console.log('Animal excluído com sucesso no servidor');
    })
    .catch(error => {
        console.error('Erro ao excluir o animal:', error);
        animalList.appendChild(row);
    });
}

function openDoacoesPage() {
    window.location.href = "doacoes.html";
}

function logout() {
    window.location.href = "login.html";
}