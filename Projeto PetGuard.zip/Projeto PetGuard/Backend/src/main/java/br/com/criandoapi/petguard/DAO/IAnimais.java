package br.com.criandoapi.petguard.DAO;

import org.springframework.data.repository.CrudRepository;

import br.com.criandoapi.petguard.model.Animais;

public interface IAnimais extends CrudRepository<Animais, String>{

}
